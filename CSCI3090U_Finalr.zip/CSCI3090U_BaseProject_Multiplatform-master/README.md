# CSCI3090U FINAL PROJECT SHANE REGO

Shane Rego 100623789

This is a OpenGL Project with that displays a simple model that is rotating,
if you drag your mouse you can enlarge or shrink it.

I worked on this project by myself, with inspiration from source code provided during labs and in class.
The blender model was an original idea but I used youtube tutorials for certain aspects as I am not completely familiar.  

An attempt was made to implement some music being played but there were some driver issues with my system, the code is still there but is commented out so the program will run smoothly. The IRRKLANG library was imported to attempt this

# How to Build


> nmake /F Nmakefile.Windows


- run the application:


> main
